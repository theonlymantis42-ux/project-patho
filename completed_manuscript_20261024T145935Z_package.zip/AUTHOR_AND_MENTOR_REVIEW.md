# Before mentor approval and submission
The manuscript writing and analysis are complete for the exploratory single-model study described. Submission readiness still requires human review and administrative information.

1. Confirm author names, order, affiliations, contributions, and corresponding-author details. No author identity was invented.
2. Mentors should review the use of PCam test-designated images for optimization, uncertain prior external exposure, single-model design, label-audit findings, and bootstrap inference from nine patients.
3. Confirm the investigator-reported approximate training counts and final language; exact unique-image identities and optimization chronology remain unavailable.
4. Obtain qualified review of the failure cases if pathological explanations are to be added. Current manuscript makes no causal tissue-appearance or saliency claim.
5. Confirm ethics/institutional requirements, funding, competing interests, acknowledgments, and an accurate AI-assistance disclosure according to the selected venue. No ethics exemption, absence of conflicts, or funding statement was fabricated.
6. Select a venue and apply its word limit, reference style, figure limits, and data/code policies. Confirm image/weight redistribution permissions before a public release.
7. Reconcile any mentor-requested methodological changes before submission. No additional training or downloads are authorized by this package.

Researcher clarification recorded 24 October 2026: all of the approximately 30000 PCam test-designated images discussed were used with model.fit. They are optimization data, not an independent internal benchmark. All CAMELYON17 runs were reported by the researcher to be in Runs.docx; the source log contains three evaluations, but does not enumerate every historically inspected image.
